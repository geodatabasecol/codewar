# -*- coding: utf-8 -*-

  #-----------------#
 #---> MongoDB <---#
#-----------------#

UrlDB = "mongodb+srv://silklips:!Fps91507856@mycrypta.ugxec.mongodb.net/?retryWrites=true&w=majority"
#--> DB
accountsDB = "accounts"

  #----------------------#
 #---> Neverinstall <---#
#----------------------#

urlNeverInstall= "https://neverinstall.com/signin"
urlGoogle = "https://accounts.google.com/signin/chrome/sync/identifier"
