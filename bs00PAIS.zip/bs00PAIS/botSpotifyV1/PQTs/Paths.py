# -*- coding: utf-8 -*-

import os

dirnamePath = os.path.dirname(__file__)

pathImg = os.path.join(dirnamePath,'..','Almacenamiento','img')